<?php
session_start(); // iniciar prcesso de sessão
if (!isset($_SESSION["USUARIOX"])) {
  header("Location:logar.php");
  session_destroy();
  exit;
} else {

  //echo $_SESSION['USUARIOX'] ;


  $USUARIOX  = $_SESSION['USUARIOX'];
}

//////////////////////// CONECTA NO BANCO DE DADOS
//$con = mysqli_connect('localhost', 'root', '', 'ck_projects');


$con = mysqli_connect('localhost', 'ckprojects_kineipe', 'P$?v5H$B4EBq', 'ckprojects_geral');

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//////////////////////// CONECTA NO BANCO DE DADOS 



header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-cache, cachehack=" . time());
header("Cache-Control: no-store, must-revalidate");
header("Cache-Control: post-check=-1, pre-check=-1", false);




function data_ini_html5($dt)
{
  if ($dt == "0000-00-00") return '';
  $yr = strval(substr($dt, 0, 4));
  $mo = strval(substr($dt, 5, 2));
  $da = strval(substr($dt, 8, 2));

  $resul1 = "$yr" . "$mo" . "$da";
  return $resul1;
}

function compara_data($data, $valor)
{

    $arrayx = str_split($data);

    while ($valor > 0) {
        $valor = $valor - 1;
        $arrayx[7] = $arrayx[7] + 1;


        if ($arrayx[7] >= 10) {
            $arrayx[7] = 0;
            $arrayx[6] = $arrayx[6] + 1;
        }




        if ($arrayx[6] >= 3) {
            $arrayx[5] = $arrayx[5] + 1;
            $arrayx[6] = $arrayx[6] - 3;



            if ($arrayx[5] >= 10) {
                $arrayx[4] = $arrayx[4] + 1;
                $arrayx[5] = 0;
            }

            if ($arrayx[4] == 1 and $arrayx[5] > 2) {
                $arrayx[3] = $arrayx[3] + 1;
                $arrayx[4] = 0;
                $arrayx[5] = 0;
            }
        }
    }

    $novadata = implode("", $arrayx);

    return $novadata;
}
?>




<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



  <meta http-equiv="cache-control" content="max-age=0" />
  <meta http-equiv="cache-control" content="no-cache" />
  <meta http-equiv="expires" content="0" />
  <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
  <meta http-equiv="pragma" content="no-cache" />
  <meta name="theme-color" content="#00688B">


  <!-- Bootstrap CSS -->

  <link rel="stylesheet" href="./css/ionicons.css" media="screen">


  <link rel="stylesheet" href="./css/bootstrap-4.5.3-dist/css/bootstrap2.min.css">
  <link rel="stylesheet" href="./css/bootstrap-4.5.3-dist/css/bootstrap.css">
  <link rel="stylesheet" href="./css/w3.css">
  <link rel="stylesheet" href="./css/icones/font-awesome/css/font-awesome.min.css" media="screen">




  <title>CK Projects</title>

  <link rel="shortcut icon" href="./css/check-logo.png">

  <style type="text/css">
    * {
      margin: 0;
      padding: 0;
    }

    /* para garantir que estes elementos ocuparão toda a tela */
    body,
    html {
      width: 100%;
      height: 100%;
      font-family: Arial, Tahoma, sans-serif;
      background: url(./css/skulls.png),  linear-gradient( #353935,#1B1212);
   }

    .styled-link:hover,
    .styled-link:focus,
    .styled-link:active {
      color: #536dfe;
    }

    .shadow-1 {
      box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.15);
    }

    .blue-hover {
      transition: all 0.25s ease-in;
      border-bottom: 5px solid transparent;
    }

    .blue-hover:hover {
      transform: translateY(-5px);

      border: none;
      border-bottom: 5px solid red;
    }




  </style>






</head>

<body>


  <?php
  include "./principal.php";
  ?>



  <!-- jQuery CDN - Slim version (=without AJAX) -->
  <script src="./css/js/jquery-3.3.1.slim.min.js" crossorigin="anonymous"></script>
  <!-- Popper.JS -->
  <script src="./css/js/popper.min.js" crossorigin="anonymous"></script>
  <!-- Bootstrap JS -->
  <script src="./css/js/bootstrap.min.js" crossorigin="anonymous"></script>
  <script src="./css/js/jquery-1.12.4.js"></script>
  <script src="./css/js/jquery-ui.js"></script>


</body>





</html>