# CK-Projects

Link: ckprojects.com.br

A ideia era juntar vários projetos pessoais em um só lugar,onde outras pessoas também pudessem usar e apresentar novas ideias.