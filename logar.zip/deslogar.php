<?php 

header("Location:logar.php");
session_destroy();
exit;
